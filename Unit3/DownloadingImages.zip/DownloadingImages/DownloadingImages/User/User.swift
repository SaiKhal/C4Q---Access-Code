//
//  User.swift
//  DownloadingImages
//
//  Created by Masai Young on 11/28/17.
//  Copyright © 2017 Masai Young. All rights reserved.
//

import Foundation

struct User: Codable {
    let info: Info
    let results: [Result]
}

struct Result: Codable {
    let cell: String
    let dob: String
    let email: String
    let gender: String
    let id: Id
    let location: Location
    let name: Name
    let nat: String
    let phone: String
    let picture: Picture
    let registered: String
}

struct Picture: Codable {
    let large: String
    let medium: String
    let thumbnail: String
}

struct Name: Codable {
    let first: String
    let last: String
    let title: String
}

struct Location: Codable {
    let city: String
    let postcode: Int
    let state: String
    let street: String
}

struct Id: Codable {
    let name: String
    let value: String?
}

struct Info: Codable {
    let page: Int
    let results: Int
    let seed: String
    let version: String
}
