//
//  ViewController.swift
//  DownloadingImages
//
//  Created by Masai Young on 11/28/17.
//  Copyright © 2017 Masai Young. All rights reserved.
//

import UIKit

class RandomUserViewController: UIViewController {

    @IBOutlet weak var userTableView: UITableView! {
        didSet {
            userTableView.dataSource = self
        }
    }
    
    var users: User? {
        didSet {
            userTableView.reloadData()
        }
    }
    
    var randomUserEndpoint: String = "https://randomuser.me/api/?results=100&exc=login&nat=US"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        RandomUserAPIClient.manager.getUsers(from: randomUserEndpoint,
                                             completionHandler: {self.users = $0},
                                             errorHandler: {print($0)})
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

// MARK: Table View Data Source
extension RandomUserViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return users?.results.count ?? 0
    }
    
    // MARK: - Cell Rendering
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = userTableView.dequeueReusableCell(withIdentifier: "UserCell", for: indexPath)
        let index = indexPath.row
        let user = users?.results[index]
        cell.textLabel?.text = user?.name.first
        cell.detailTextLabel?.text = user?.phone
        
        // MARK: - Downloads images async
        if let albumURL = URL(string: (user?.picture.thumbnail)!) {
            
            // doing work on a background thread
            DispatchQueue.global().sync {
                if let data = try? Data.init(contentsOf: albumURL) {
                    // go back to main thread to update UI
                    DispatchQueue.main.async {
                        cell.imageView?.image = UIImage(data: data)
                        cell.setNeedsLayout()
                    }
                }
            }
        }
        return cell
    }
    
}
