//
//  PokemonDetailViewController.swift
//  DownloadingImages
//
//  Created by Masai Young on 11/28/17.
//  Copyright © 2017 Masai Young. All rights reserved.
//

import UIKit

class PokemonDetailViewController: UIViewController {

    var card: Card! {
        didSet {
            if let albumURL = URL(string: (card?.imageUrlHiRes)!) {
                
                // doing work on a background thread
                DispatchQueue.global().sync {
                    if let data = try? Data.init(contentsOf: albumURL) {
                        // go back to main thread to update UI
                        DispatchQueue.main.async {
                            self.hiResPokemonImageView.image = UIImage(data: data)
                        }
                    }
                }
            }
        }
    }
    
    @IBOutlet weak var setLabel: UILabel!
    @IBOutlet weak var weaknessLabel: UILabel!
    @IBOutlet weak var typeLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var hiResPokemonImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpLabels(from: card!)
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func setUpLabels(from card: Card) {
        nameLabel.text = card.name
        typeLabel.text = card.types?.reduce("Type: ", {$0 + "\($1)."})
        weaknessLabel.text = card.weaknesses?.reduce("Weakness: ", {$0 + "\($1.type)."})
        setLabel.text = card.set
    }
}
