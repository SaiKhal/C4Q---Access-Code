//
//  NetworkManager.swift
//  DownloadingImages
//
//  Created by Masai Young on 11/28/17.
//  Copyright © 2017 Masai Young. All rights reserved.
//

import Foundation

class NetworkHelper {
    private init() {}
    static let manager = NetworkHelper()
    let urlSession = URLSession(configuration: URLSessionConfiguration.default)
    func performDataTask(with url: URL, completionHandler: @escaping ((Data) -> Void), errorHandler: @escaping ((Error) -> Void)) {
        self.urlSession.dataTask(with: url){(data: Data?, response: URLResponse?, error: Error?) in
            DispatchQueue.main.async {
                guard let data = data else {
                    return
                }
                if let error = error {
                    errorHandler(error)
                }
                completionHandler(data)
            }
            }.resume()
    }
}

struct RandomUserAPIClient {
    private init() {}
    static let manager = RandomUserAPIClient()
    func getUsers(from urlStr: String, completionHandler: @escaping (User) -> Void, errorHandler: (Error) -> Void) {
        guard let url = URL(string: urlStr) else {return}
        let completion: (Data) -> Void = {(data: Data) in
            do {
                let users = try JSONDecoder().decode(User.self, from: data)
                completionHandler(users)
            }
            catch {
                print(error)
            }
        }
        NetworkHelper.manager.performDataTask(with: url,
                                              completionHandler: completion,
                                              errorHandler: {print($0)})
    }
}

struct ComicAPIClient {
    private init() {}
    static let manager = ComicAPIClient()
    func getComics(from urlStr: String, completionHandler: @escaping (Comic) -> Void, errorHandler: (Error) -> Void) {
        guard let url = URL(string: urlStr) else {return}
        let completion: (Data) -> Void = {(data: Data) in
            do {
                let comics = try JSONDecoder().decode(Comic.self, from: data)
                completionHandler(comics)
            }
            catch {
                print(error)
            }
        }
        NetworkHelper.manager.performDataTask(with: url,
                                              completionHandler: completion,
                                              errorHandler: {print($0)})
    }
}

struct PokemonAPIClient {
    private init() {}
    static let manager = PokemonAPIClient()
    func getPokemon(from urlStr: String, completionHandler: @escaping (Pokemon) -> Void, errorHandler: (Error) -> Void) {
        guard let url = URL(string: urlStr) else {return}
        let completion: (Data) -> Void = {(data: Data) in
            do {
                let pokemon = try JSONDecoder().decode(Pokemon.self, from: data)
                completionHandler(pokemon)
            }
            catch {
                print(error)
            }
        }
        NetworkHelper.manager.performDataTask(with: url,
                                              completionHandler: completion,
                                              errorHandler: {print($0)})
    }
}

