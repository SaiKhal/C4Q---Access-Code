//
//  Pokemon.swift
//  DownloadingImages
//
//  Created by Masai Young on 11/28/17.
//  Copyright © 2017 Masai Young. All rights reserved.
//

import Foundation

struct Pokemon: Codable {
    let cards: [Card]
}

struct Card: Codable {
    let ability: Ability?
    let ancientTrait: AncientTrait?
    let artist: String
    let attacks: [Attacks]?
    let evolvesFrom: String?
    let hp: String?
    let id: String
    let imageUrl: String
    let imageUrlHiRes: String
    let name: String
    let nationalPokedexNumber: Int?
    let number: String
    let rarity: String
    let resistances: [Resistances]?
    let retreatCost: [String]?
    let series: String
    let set: String
    let setCode: String
    let subtype: String
    let supertype: String
    let text: [String]?
    let types: [String]?
    let weaknesses: [Resistances]?
}

struct Resistances: Codable {
    let type: String
    let value: String
}

struct Attacks: Codable {
    let convertedEnergyCost: Int
    let cost: [String]
    let damage: String
    let name: String
    let text: String
}

struct AncientTrait: Codable {
    let name: String
    let text: String
}

struct Ability: Codable {
    let name: String
    let text: String
    let type: String
}

