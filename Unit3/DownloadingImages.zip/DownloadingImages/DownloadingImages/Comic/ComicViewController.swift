//
//  ComicViewController.swift
//  DownloadingImages
//
//  Created by Masai Young on 11/28/17.
//  Copyright © 2017 Masai Young. All rights reserved.
//

import UIKit

class ComicViewController: UIViewController {

    var comic: Comic? {
        didSet {
            setUpPage()
            if (comic?.num)! >= Int(comicStepper.maximumValue) {
                comicStepper.maximumValue = Double((comic?.num)!)
            }
            comicStepper.value = Double((comic?.num)!)
        }
    }
    
    var mostRecentComicEndpoint = "http://xkcd.com/info.0.json"
    
    var numberedComicEndpoint: String? {
        return "https://xkcd.com/\(comicNumber)/info.0.json"
    }
    
    var randomComicEndpoint: String {
        return "https://xkcd.com/\(randomNumber)/info.0.json"
    }
    
    var comicNumber = 834 {
        didSet {
            fetchComic(from: numberedComicEndpoint)
        }
    }
    
    var randomNumber: Int {
        return Int(arc4random_uniform(UInt32(1921)))
    }
    
    
    @IBOutlet weak var comicImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var comicNumberLabel: UILabel!
    @IBOutlet weak var comicStepper: UIStepper!
    @IBOutlet weak var mostRecentComicButton: UIButton!
    @IBOutlet weak var randomComicButton: UIButton!
    @IBOutlet weak var comicTextField: UITextField! {
        didSet {
            comicTextField.delegate = self
        }
    }
    
    @IBAction func stepperValueChanged(_ sender: UIStepper) {
        comicNumber = Int(sender.value)
    }
    
    @IBAction func mostRecentPressed(_ sender: Any) {
        fetchComic(from: mostRecentComicEndpoint)
    }
    
    @IBAction func randomPressed(_ sender: Any) {
        fetchComic(from: randomComicEndpoint)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        fetchComic(from: numberedComicEndpoint)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func setUpPage() {
        if let albumURL = URL(string: (comic?.img)!) {
            
            // doing work on a background thread
            DispatchQueue.global().sync {
                if let data = try? Data.init(contentsOf: albumURL) {
                    // go back to main thread to update UI
                    DispatchQueue.main.async {
                        self.comicImageView.image = UIImage(data: data)
                    }
                }
            }
        }
        titleLabel.text = comic?.safe_title
        comicNumberLabel.text = String((comic?.num)!)
    }
    
    func fetchComic(from endpoint: String?) {
        ComicAPIClient.manager.getComics(from: endpoint!,
                                         completionHandler: {self.comic = $0},
                                         errorHandler: {print($0)})
    }
}

extension ComicViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        guard let comicNum = Int(textField.text!) else { return false }
        comicNumber = comicNum
        print(comicNumber)
        return true
    }
}


